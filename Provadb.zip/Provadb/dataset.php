<?php

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbecommerce";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read the CSV file
$csvFile = 'watches_dataset.csv';
$handle = fopen($csvFile, "r");

// Parse CSV and insert data into the database
if ($handle !== FALSE) {
    // Read the header row to get column names
    $header = fgetcsv($handle);
    
    // Map CSV columns to database columns
    $csvColumns = array('Brand', 'Model', 'Case Material', 'Strap Material', 'Movement Type', 'Water Resistance', 'Case Diameter (mm)', 'Case Thickness (mm)', 'Band Width (mm)', 'Dial Color', 'Crystal Material', 'Complications', ' Power Reserve', 'Price (USD)'); // Add more columns as needed

    while (($data = fgetcsv($handle)) !== FALSE) {
        // Create an associative array of watch data
        $watchData = array_combine($csvColumns, $data);

        $result = scrapeChrono24WatchDetails($watchData['Model'], $watchData['Brand']);

        // Prepare INSERT statement
        $sql = "INSERT INTO prodotto (modello, movimento, materiale_cassa, diametro_cassa, colore_quadrante, impermeabilità, funzioni, prezzo, immagine, disponibilità, categoria, marca) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        
        $model = $watchData['Model'];
        $movement_type = $watchData['Movement Type'];
        $case_material = $watchData['Case Material'];
        $case_diameter = $watchData['Case Diameter (mm)'];
        $dial_color = $watchData['Dial Color'];
        $water_resistance = $watchData['Water Resistance'];
        $complications = $watchData['Complications'];
        $price = $watchData['Price (USD)'];
        $image_url = $result['image_url']; // Assuming $result contains data from image scraping
        $availability = 1; // Assuming this represents "available"
        $category = $result['category'];
        $brand = $watchData['Brand'];

        $stmt->bind_param("ssssssssssss", 
            $model, 
            $movement_type, 
            $case_material, 
            $case_diameter, 
            $dial_color, 
            $water_resistance, 
            $complications, 
            $price, 
            $image_url, 
            $availability, 
            $category, 
            $brand
        );

        // Execute the statement
        $stmt->execute();
        
        // Check for errors
        if ($stmt->error) {
            echo "Error: " . $stmt->error . "<br>";
        } else {
            echo "Inserted data successfully!<br>";
        }
    }

    fclose($handle);
} else {
    echo "Failed to open file.";
}

// Close connection
$conn->close();



function scrapeChrono24WatchDetails($model, $brand) {
    require 'simple_html_dom.php'; // Include Simple HTML DOM Parser library
    // Construct search URL
    $searchUrl = "https://www.chrono24.com/search/index.htm?query=" . urlencode($model . " " . $brand);
    
    // Initialize cURL session
    $curl = curl_init($searchUrl);
    
    // Set cURL options
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    
    // Execute cURL request
    $html = curl_exec($curl);
    
    // Close cURL session
    curl_close($curl);
    
    // Check if request was successful
    if ($html === false) {
        echo "Failed to retrieve data from Chrono24";
        return;
    }
    
    // Parse HTML content
    $dom = new simple_html_dom();
    $dom->load($html);
    
    // Find product image URL
    $imageElement = $dom->find('#article img', 0);
    $imageUrl = '';
    if ($imageElement) {
        $imageUrl = 'https:' . $imageElement->src;
    }
    
    // Find product category
    $categoryElement = $dom->find('#categories-header a', 0);
    $category = '';
    if ($categoryElement) {
        $category = $categoryElement->plaintext;
    }
    
    $dom->clear(); // Clear DOM object
    unset($dom); // Free memory
    
    return array(
        'image_url' => $imageUrl,
        'category' => $category
    );
}



?>
