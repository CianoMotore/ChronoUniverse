<?php
include('simple_html_dom.php');
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbecommerce";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read the CSV file
$csvFile = 'watches_dataset.csv';
$handle = fopen($csvFile, "r");

// Parse CSV and insert data into the database
if ($handle !== FALSE) {
    // Read the header row to get column names
    $header = fgetcsv($handle);
    
    // Map CSV columns to database columns
    $csvColumns = array('Brand', 'Model', 'Case Material', 'Strap Material', 'Movement Type', 'Water Resistance', 'Case Diameter (mm)', 'Case Thickness (mm)', 'Band Width (mm)', 'Dial Color', 'Crystal Material', 'Complications', ' Power Reserve', 'Price (USD)'); // Add more columns as needed

    while (($data = fgetcsv($handle)) !== FALSE) {
        // Create an associative array of watch data
        $watchData = array_combine($csvColumns, $data);

        $result = scrapeImage($watchData);

        // Prepare INSERT statement
        $sql = "INSERT INTO prodotto (modello, movimento, materiale_cassa, diametro_cassa, colore_quadrante, impermeabilità, funzioni, prezzo, immagine, disponibilità, marca) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        
        $model = $watchData['Model'];
        $movement_type = $watchData['Movement Type'];
        $case_material = $watchData['Case Material'];
        $case_diameter = $watchData['Case Diameter (mm)'];
        $dial_color = $watchData['Dial Color'];
        $water_resistance = $watchData['Water Resistance'];
        $complications = $watchData['Complications'];
        $price = $watchData['Price (USD)'];
        //$image_url = $result['image_url']; // Assuming $result contains data from image scraping
        $availability = 1; // Assuming this represents "available"
        //$category = $result['category'];
        $brand = $watchData['Brand'];

        $stmt->bind_param("sssssssssss", 
            $model, 
            $movement_type, 
            $case_material, 
            $case_diameter, 
            $dial_color, 
            $water_resistance, 
            $complications, 
            $price, 
            $result, 
            $availability, 
            //$category, 
            $brand
        );

        // Execute the statement
        $stmt->execute();
        
        // Check for errors
        if ($stmt->error) {
            echo "Error: " . $stmt->error . "<br>";
        } else {
            echo "Inserted data successfully!<br>";
        }
    }

    fclose($handle);
} else {
    echo "Failed to open file.";
}

// Close connection
$conn->close();

function scrapeImage($watchData) {
    // Build the search query using the watch model data
    $query = $watchData['Brand'] . ' ' . $watchData['Model'] . ' watch';

    // URL for Google Image search
    $googleImageUrl = 'https://www.google.com/search?tbm=isch&q=' . urlencode($query);

    // Get the HTML content of the Google Image search page
    $html = file_get_contents($googleImageUrl);

    // Create a Simple HTML DOM Parser object
    $dom = new simple_html_dom();
    $dom->load($html);

    // Find the first image on the page
    foreach ($dom->find('img') as $element) {
        // Return the URL of the first image found
        return $element->src;
    }

    return null; // Return null if no image is found
}

?>
