<?php
# chrono24_scraper.php

require 'vendor/autoload.php';

use Goutte\Client;

$client = new Client();

$model = 'Submariner';
$brand = 'Rolex';

$searchUrl = "https://www.chrono24.com/search/index.htm?query=" . urlencode($model . " " . $brand);

$crawler = $client->request('GET', $searchUrl);

// Find image URLs
$imageUrls = $crawler->filter('.content img.img-responsive')->extract(['src']);

// Find watch categories
$categories = $crawler->filter('.content .watch-details h4')->each(function ($node) {
    return $node->text();
});

echo "Image URLs:" . PHP_EOL;
print_r($imageUrls);

echo "Watch Categories:" . PHP_EOL;
print_r($categories);
?>
