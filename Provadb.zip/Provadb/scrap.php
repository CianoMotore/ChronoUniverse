<?php

// Include the PHP Simple HTML DOM Parser library
include('simple_html_dom.php');

function scrapeImage($watchData) {
    // Build the search query using the watch model data
    $query = $watchData['Brand'] . ' ' . $watchData['Model'] . ' watch';

    // URL for Google Image search
    $googleImageUrl = 'https://www.google.com/search?tbm=isch&q=' . urlencode($query);

    // Get the HTML content of the Google Image search page
    $html = file_get_contents($googleImageUrl);

    // Create a Simple HTML DOM Parser object
    $dom = new simple_html_dom();
    $dom->load($html);

    // Find the first image on the page
    foreach ($dom->find('img') as $element) {
        // Return the URL of the first image found
        return $element->src;
    }

    return null; // Return null if no image is found
}

// Example watch data
$watchData = [
    'Brand' => 'Rolex',
    'Model' => 'Submariner',
    'Case Material' => 'Stainless Steel',
    'Strap Material' => 'Oystersteel',
    'Movement Type' => 'Automatic',
    'Water Resistance' => '300 meters',
    'Case Diameter (mm)' => '40',
    'Case Thickness (mm )' => '12',
    'Band Width (mm)' => '20',
    'Dial Color' => 'Black',
    'Crystal Material' => 'Sapphire',
    'Complications' => 'Date',
    'Power Reserve' => '48 hours',
    'Price (USD)' => '8000'
];

// Scrape the watch image
$imageUrl = scrapeImage($watchData);

// Display the URL of the image
if ($imageUrl) {
    echo "Watch Image URL: $imageUrl";
} else {
    echo "No image found for the watch.";
}
?>
