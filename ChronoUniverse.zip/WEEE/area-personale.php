<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/personal-style.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <title>ChronoUniverse Area Personale</title>
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="">Shop</a></li>
                <li><a href="">Blog</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href=""><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href="login.php" class="active"><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>
    
    <div>
        <a href="#">Change Profile</a>
        <a href="logout.php"> <button class="btn">Log Out</button> </a>
    </div>
</body>
</html>