<?php
   session_start();
   include("config.php");

   $redirect_link = isset($_SESSION['valid']) ? "area-personale.php" : "login.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
    <section id="header">
        <a href="index.php"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="">Shop</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href=""><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=<?php echo $redirect_link; ?>><i class="fa fa-user"></i></a></li>
            </ul>

            <?php
                // $id =  $_SESSION['valid'];
                // $query = mysqli_query($conn, "SELECT * FROM cliente WHERE email = '$email'")

                // while($result = mysqli_fetch_assoc($query)){
                //     $res_name = $result['name'];
                //     $res_surname = $result['surname'];
                //     $res_birthDate = $result['birthDate'];
                //     $res_email = $result['email'];
                //     $res_address = $result['address'];
                //     $res_phone = $result['phone'];
                //     $res_password = $result['password'];
                // }
            ?>
        </div>
    </section>

    <section id="hero">
        <h3>Trova il tuo orologio sulla più grande piattaforma online di orologi di lusso.</h3>
        <form action="shop.php" class="search-bar">
            <input type="text" name="" id="live_search" placeholder="Cerca un orologio" autocomplete="off">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>

        <div id="searchresult"></div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <script type="text/javascript">
            $(document).ready(function(){
                $("#live_search").keyup(function(){
                    var input = $(this).val();
                    if(input != ""){
                        $.ajax({
                        url: "livesearch.php",
                        method:"POST",
                        data:{input:input},
                        success:function(data){
                        $("#searchresult").html(data);
                        $("#searchresult").css("display", "block");}
                        })
                    } 
                    else 
                    $("#searchresult").css("display", "none");
                });

                // Gestione del clic sui risultati
                $(document).on("click", ".search-result", function(){
                    var modello = $(this).data("modello");
                    $("#live_search").val(modello); // Scrive il valore del modello nella search bar
                    $("#searchresult").css("display", "none"); // Nasconde i risultati della ricerca
                });
            });
        </script>

    </section>

    <p style="text-align: center; margin: 20px 0 0 0;">Marche più cercate</p>
    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="IMG/rolex.png" alt="rolex">
        </div>
        <div class="fe-box">
            <img src="IMG/cartier.png" alt="cartier">
        </div>
        <div class="fe-box">
            <img src="IMG/tudor.webp" alt="tudor">
        </div>
        <div class="fe-box">
            <img src="IMG/oris.jpg" alt="oris">
        </div>
        <div class="fe-box">
            <img src="IMG/patek-philippe.png" alt="patek-philippe">
        </div>
        <div class="fe-box">
            <img src="IMG/zenith.png" alt="zenith">
        </div>
    </section>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script src="JS/script.js"></script>
</body>

</html>