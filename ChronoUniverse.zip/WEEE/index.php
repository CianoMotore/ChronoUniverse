<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
    <section id="header">
        <a href="#"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="">Shop</a></li>
                <li><a href="">Blog</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href=""><i class="fa fa-shopping-cart"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="hero">
        <h4>La più grande piattaforma online di orologi di lusso</h4>
        <h2>Scegli tra i migliori brand</h2>
        <h1>Non perderti le migliori offerte</h1>
        <button>Shop Now</button>
    </section>

    <script src="JS/script.js"></script>
</body>

</html>