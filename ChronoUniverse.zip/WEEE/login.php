<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/login-style.css">
    <title>ChronoUniverse Sign In</title>
</head>
<body>
    <div class="container">
        <div class="box form-box">
            <?php
                include("config.php");
                if(isset($_POST["submit"])){
                    $email = mysqli_real_escape_string($conn, $_POST['email']);
                    $password = mysqli_real_escape_string($conn, $_POST['password']);

                    $result = mysqli_query($conn, "SELECT * FROM cliente WHERE email='$email' AND pwd='$password'") or die("Select error");
                    $row = mysqli_fetch_assoc($result);

                    if(is_array($row) && !empty($row)){
                        $_SESSION['name'] = $row['name'];
                        $_SESSION['username'] = $row['username'];
                        $_SESSION['birthDate'] = $row['birthDate'];
                        $_SESSION['valid'] = $row['email'];
                        $_SESSION['address'] = $row['address'];
                        $_SESSION['phone'] = $row['phone'];
                        $_SESSION['password'] = $row['password'];

                        if(isset($_SESSION['valid'])){
                        }
    
                        header("Location: index.php");
                        exit();
                    }
                    else{
                        echo "<script>alert('Email o Password errate');</script>";
                    }                
                }
            ?>
            <header>Sign In</header>
            <form action="" method="post">
                <div class="field input">
                    <input type="email" name="email" id="email" placeholder="Email" required autocomplete="off">
                </div>
                
                <div class="field input">
                    <input type="password" name="password" id="password" placeholder="Password" required autocomplete="off">
                </div>

                <div class="field">
                    <input type="submit" name="submit" class="btn" value="Sign In">
                </div>

                <div class="links">
                    Non hai un account ? <a href="register.php">Sign Up</a><br><br>
                    Torna alla <a href="index.php">Home</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>