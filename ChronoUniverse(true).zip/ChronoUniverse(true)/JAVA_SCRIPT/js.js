// Simulating wishlist and cart item counts (replace with actual logic)
/*let wishlistCount = 0; 
let cartCount = 0;

const wishlistCountEl = document.querySelector('.wishlist-count');
const cartCountEl = document.querySelector('.cart-count');

function updateCounts() {
   wishlistCountEl.textContent = wishlistCount;
   cartCountEl.textContent = cartCount;
}

// Example - add to wishlist
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-wishlist')) {
        wishlistCount++;
        updateCounts();
    }
});

// ... your existing JavaScript ...

const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {  
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});
*/
