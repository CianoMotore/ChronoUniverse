<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orologi E-commerce</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="JAVA_SCRIPT/js.js"></script>
</head>


<body>
<nav class="navbar">
  <div class="logo">
    <a href="index.html">ChronoUniverse</a> 
  </div>

  <ul class="nav-links">
    <li><a href="#">Men</a></li>
    <li><a href="#">Women</a></li>
    <li><a href="#">Brands</a></li>
  </ul>

  <div class="icons">
    <!-- <div class="search-container">
    <form method="post" action="/action_page.php" id="search-form">
      <input type="text" placeholder="Search.." name="search" id="search-input">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
    </div>
    
    <a href="cart.html" class="cart-icon">
        <i class="fas fa-shopping-cart"></i>
        <span class="cart-count"><img src="IMAGES/wishList.png" alt="wishList"></span> 
    </a>
    <a href="wishlist.html" class="wishlist-icon">
        <i class="fas fa-heart"></i>
        <span class="wishlist-count"><img src="IMAGES/shoppingCart.png" alt="shoppingCart"></span> 
    </a> -->
    <div class="search-container">
    <form method="post" action="/action_page.php" id="search-form">
      <input type="text" placeholder="Search.." name="search" id="search-input">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
    </div>
    
    
    <a href="wishlist.html" class="wishlist-icon">
        <i class="fa fa-heart"></i>
        <span class="wishlist-count">0</span> 
    </a>
    <a href="cart.html" class="cart-icon">
        <i class="fa fa-shopping-cart"></i>
        <span class="cart-count">0</span>
    </a>
  </div>
  <div class="auth-buttons">
    <a href="signup.html" class="btn btn-signup">Sign Up</a>
    <a href="signin.html" class="btn btn-signin">Sign In</a> 
  </div>
</nav>



    
</body>
</html>


