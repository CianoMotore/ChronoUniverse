<?php
    // Connessione al database
    session_start();
    include("config.php");

    // Query per ottenere gli ordini del cliente corrente
    $id_cliente = $_SESSION['valid'];

    // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
    if (isset($_SESSION['valid'])) {
        // Ottieni l'email del cliente dalla sessione
        $email_cliente = $_SESSION['valid'];
    
        // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
        $query = "SELECT O.id_ordine, O.data_ordine, O.stato, P.modello, P.movimento, DO.prezzo, O.costo_spedizione, P.immagine, DO.quantità, O.indirizzo_spedizione, O.data_consegna
                  FROM Ordine O
                  INNER JOIN DettaglioOrdine DO ON O.id_ordine = DO.codice_ordine
                  INNER JOIN Prodotto P ON DO.codice_orologio = P.id_orologio
                  INNER JOIN Cliente C ON O.codice_cliente = C.email
                  WHERE C.email = ?";
    
        // Prepara la query
        $stmt = $conn->prepare($query);
    
        // Verifica se la query è stata preparata correttamente
        if ($stmt === false) {
            die("Errore di preparazione della query: " . $conn->error);
        }
    
        // Esegui il binding del parametro
        $stmt->bind_param("s", $email_cliente);
    
        // Esegui la query
        $stmt->execute();
    
        // Ottieni il risultato della query
        $result = $stmt->get_result();
    
        // Verifica se ci sono risultati
        if ($result->num_rows > 0) {
            // Output dei dettagli degli ordini con informazioni del prodotto associato
            echo "<table>";
            echo "<tr>
                    <th>Ordine</th>
                    <th>Data Ordine</th>
                    <th>Stato</th>
                    <th>Costo Spedizione</th>
                    <th>Indirizzo Spedizione</th>
                    <th>Data Consegna</th>
                    <th>Prodotto</th>
                    <th>Movimento</th>
                    <th>Prezzo</th>
                    <th>Quantità</th>
                    <th>Immagine</th>
                </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id_ordine'] . "</td>";
                echo "<td>" . $row['data_ordine'] . "</td>";
                echo "<td>" . $row['stato'] . "</td>";
                echo "<td>" . $row['costo_spedizione'] . "</td>";
                echo "<td>" . $row['indirizzo_spedizione'] . "</td>";
                echo "<td>" . $row['data_consegna'] . "</td>";
                echo "<td>" . $row['modello'] . "</td>";
                echo "<td>" . $row['movimento'] . "</td>";
                echo "<td>" . $row['prezzo'] . "</td>";
                echo "<td>" . $row['quantità'] . "</td>";
                echo '<td><img src="' .$row['immagine']. '" /></td>';
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>Nessun ordine trovato.</p>";
        }
    
        // Chiudi la connessione al database
        $stmt->close();
        $conn->close();
    } else {
        // L'utente non è loggato o non ha un'email associata
        echo "<p>Si è verificato un errore nel recupero degli ordini.</p>";
    }
?>