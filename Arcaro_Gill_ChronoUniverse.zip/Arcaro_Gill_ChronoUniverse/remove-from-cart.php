<?php
    // Perform the removal of the product from the cart
    if (isset($_GET['id'])) {
        $productIdToRemove = $_GET['id'];
        $cartData = json_decode($_COOKIE['cart'], true);

        // Remove the item from the cart data
        foreach ($cartData as $key => $item) {
            if ($item['id_orologio'] == $productIdToRemove) {
                unset($cartData[$key]);
                break;
            }
        }
        
        // Re-encode cart data and update cookie
        setcookie('cart', json_encode($cartData), time() + (86400 * 30), '/'); // Set cookie expiration for 30 days
        $cartHtml = generateCartHtml($cartData);

    } else {
        // Handle invalid request
        echo 'Invalid request';
        exit();
    }

    function generateCartHtml($cartData) {
        $cartItems = '';
        $total = 0;
        $cartSection = "";
        if(!empty($cartData)){

            foreach ($cartData as $item) {
                $productId = $item['id_orologio'];
                $image = $item['immagine'];
                $price = $item['prezzo'];
                $quantity = $item['quantità'];
                $brand = $item['marca'];
                $model = $item['modello'];
                $subtotal = $price * $quantity;
                $total += $subtotal;
                $cartItems .= "<tr>
                                        <td><a href='#' class='remove-item' data-product-id='$productId'><i class='fa fa-times'></i></a></td>
                                        <td><img src='$image' alt='$brand $model'></td>
                                        <td>$brand $model</td>
                                        <td>$price €</td>
                                        <td><input type='number' value='$quantity' name='quantity[$productId]' readonly></td>
                                        <td>$subtotal €</td>
                                    </tr>";
            }
        }

        // Invia la risposta JSON
        echo json_encode(array(
            'success' => true,
            'cartHtml' => $cartItems,
            'Totale'  => $total
        ));
        exit();
    }
?>
