<?php
   session_start();
   include("config.php");

   $redirect_link = isset($_SESSION['valid']) ? "area-personale.php" : "login.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php" class="active">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cart.php"><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=<?php echo $redirect_link; ?>><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="page-header" class="blog-header">
        <h2>#ReadMore</h2>
        <p>Read all case studies about our products! </p>
    </section>

    <section id="blog">
        <div class="blog-box">
            <div class="blog-img">
                <img src="https://www.paradisoluxury.com/25747-extralarge_default/date-service-rolex.jpg" alt="Rolex Submariner">
            </div>
            <div class="blog-details">
                <h4>Rolex Submariner: L'essenza dell'avventura subacquea</h4>
                <p>Un'icona senza tempo: Il Rolex Submariner, nato nel 1953, rappresenta un'icona leggendaria nel mondo dell'orologeria subacquea. Con la sua robustezza ineguagliabile, la sua leggibile...</p>
                <a href="#">CONTIUNUE READING</a>
            </div>
            <h1>13/01</h1>
        </div>

        <div class="blog-box">
            <div class="blog-img">
                <img src="https://imageapi.cambiaste.com/api/lotto/immagine/266346.jpg" alt="Omega Seamaster">
            </div>
            <div class="blog-details">
                <h4>Omega Seamaster: L'eleganza incontra l'avventura</h4>
                <p>Il Seamaster si distingue per il suo design raffinato e iconico. La cassa in acciaio inossidabile, la lunetta...</p>
                <a href="#">CONTIUNUE READING</a>
            </div>
            <h1>14/01</h1>
        </div>

        <div class="blog-box">
            <div class="blog-img">
                <img src="https://samiwatches.com/wp-content/uploads/2023/07/CBS2212.FC6535-2-scaled.webp" alt="TAG Heuer Carrera">
            </div>
            <div class="blog-details">
                <h4>TAG Heuer Carrera: Sfida il tempo con stile</h4>
                <p>Il Carrera vanta una cassa in acciaio inossidabile robusta e raffinata, una lunetta girevole con tachimetro e un quadrante sportivo con indici e lancette...</p>
                <a href="#">CONTIUNUE READING</a>
            </div>
            <h1>15/01</h1>
        </div>

        <div class="blog-box">
            <div class="blog-img">
                <img src="https://cdn2.chrono24.com/images/uhren/32911703-nwnitc30sjxgc95mqqg09iw5-ExtraLarge.jpg" alt="Breitling Navitimer">
            </div>
            <div class="blog-details">
                <h4>Breitling Navitimer: L'anima dell'aviazione al tuo polso</h4>
                <p>Il Navitimer vanta una cassa in acciaio inossidabile robusta e resistente, un quadrante chiaro e leggibile con indici luminescenti e un movimento automatico...</p>
                <a href="#">CONTIUNUE READING</a>
            </div>
            <h1>16/01</h1>
        </div>

        <div class="blog-box">
            <div class="blog-img">
                <img src="https://cdn2.chrono24.com/images/uhren/30062195-u1ncc1iw3tdp3madsjgy8dl6-ExtraLarge.jpg" alt="Cartier Tank Solo">
            </div>
            <div class="blog-details">
                <h4>Cartier Tank Solo: L'essenza dell'eleganza senza tempo</h4>
                <p>Il Tank Solo vanta una cassa in acciaio inossidabile o oro, caratterizzata dalle linee pulite e geometriche. Il quadrante argentato o opalino, con numeri romani e lancette a gladio...</p>
                <a href="#">CONTIUNUE READING</a>
            </div>
            <h1>17/01</h1>
    </section>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

</body>
</html>