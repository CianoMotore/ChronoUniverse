<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="CSS/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="IMG/logo.png" width="10%" alt="logo">
                </span>
                <div class="text header-text">
                    <span class="profession">ChronoUniverse</span>
                </div>
            </div>

            <i class="fas fa-chevron-right toggle"></i>
        </header>

        <div class="menu-bar">
            <div class="menu">
                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="index.php">
                            <i class="fas fa-home icon"></i>
                            <span class="text nav-text">Torna alla Home</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="#orders">
                            <i class="fas fa-box-open icon"></i>
                            <span class="text nav-text">I Miei Ordini</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="#info">
                            <i class="fas fa-user-circle icon"></i>
                            <span class="text nav-text">Info Account</span>
                        </a>
                    </li>

                    <!-- <li class="nav-link">
                        <a href="#">
                            <i class="fas fa-heart icon"></i>
                            <span class="text nav-text">WishList</span>
                        </a>
                    </li> -->
                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt icon"></i>
                        <span class="text nav-text">Log Out</span>
                    </a>
                </li>

                <li class="mode">
                    <div class="moon-sun">
                        <i class="fas fa-moon icon moon"></i>
                        <i class="fas fa-sun icon sun"></i>
                    </div>

                    <span class="mode-text text">Dark Mode</span>   

                    <div class="toggle-switch">
                        <span class="switch"></span>
                    </div>
                </li>
            </div>

        </div>
    </nav>

    <section class="home">
        <div class="text" style="text-align:center">Dashboard</div>
        <div class="orders-table" id="order-details"></div>
        <div class="update-profile" id="account-details">
            
        </div>
    </section>

    <script src="JS/profile.js"></script>
</body>
</html>



