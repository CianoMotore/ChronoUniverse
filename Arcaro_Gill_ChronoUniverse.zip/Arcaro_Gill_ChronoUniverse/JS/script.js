function VerificaCasella(char){
    let string;

    if(char == 'n')
        string = document.getElementById("name").value;

    else
        string = document.getElementById("surname").value;

    for(let i = 0; i<string.length; i++){
        if(!isNaN(string[i]) && string[i]!= " " ){
            Reset(char);
            break;
        }
    }
    
}

function Reset(char){
    switch(char){
        case 'n':
            alert("Nome inserito non valido");
            document.getElementById("name").value = "";
            document.getElementById("name").focus();
            break;
        case 's':
            alert("Cognome inserito non valido");
            document.getElementById("surname").value = "";
            document.getElementById("surname").focus();
            break;
        case 't':
            alert("Numero inserito non valido");
            document.getElementById("phone").value = "";
            document.getElementById("phone").focus();
            break;  
        case 'd':
            alert("Chia ha meno di 16 anni non può registrarsi al sito");
            document.getElementById("birthDate").value = "";
            document.getElementById("birthDate").focus();
            break;  
        default:
            break;
    }
    
}

function checkPhoneNumber() {
    // Regex per un numero di telefono italiano (es. +39 0123456789)
    var phoneRegex = /^\+(?:[0-9] ?){6,14}[0-9]$/;

    // Prendi il valore dall'input
    var phoneNumber = document.getElementById('phone').value;

    // Controlla se il valore corrisponde alla regex
    if (!phoneRegex.test(phoneNumber) && document.getElementById('phone').value != "") {
        Reset('t');
    }
}

function checkDateOfBirth() {
    var birth = document.getElementById('birthDate').value;
    var today = new Date();
    var birthDate = new Date(birth);
    var age = today.getFullYear() - birthDate.getFullYear();
    var monthDiff = today.getMonth() - birthDate.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

    if (age < 16 && document.getElementById('birthDate').value != "") {
        Reset('d');
    }
}