const body = document.querySelector("body"),
    sidebar = body.querySelector(".sidebar"),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");

    toggle.addEventListener("click", () =>{
        sidebar.classList.toggle("close");
    });

    modeSwitch.addEventListener("click", () =>{
        body.classList.toggle("dark");

        if(body.classList.contains("dark")){
            modeText.innerText = "Light Mode"
        }else{
            modeText.innerText = "Dark Mode"
        }
    });

    document.addEventListener("DOMContentLoaded", function() {
        // Aggiungi un listener per il click su "I Miei Ordini"
        document.querySelector('a[href="#orders"]').addEventListener('click', function() {
            // Effettua una richiesta AJAX per ottenere i dettagli dell'ordine
            document.getElementById('account-details').style.display = 'none';
            document.getElementById('order-details').style.display = 'block';
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'get_orders.php', true);
            xhr.onload = function() {
                if (xhr.status == 200) {
                    // Inserisci i dettagli dell'ordine nella sezione appropriata
                    document.getElementById('order-details').innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        });
    });

    document.addEventListener("DOMContentLoaded", function() {
        // Aggiungi un listener per il click su "I Miei Ordini"
        document.querySelector('a[href="#info"]').addEventListener('click', function() {
            // Effettua una richiesta AJAX per ottenere i dettagli dell'ordine
            document.getElementById('order-details').style.display = 'none';
            document.getElementById('account-details').style.display = 'block';
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'get_info.php', true);
            xhr.onload = function() {
                if (xhr.status == 200) {
                    // Inserisci i dettagli dell'ordine nella sezione appropriata
                    document.getElementById('account-details').innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        });
    });

    function mostraPassword(inputId) {
        var passwordField = document.getElementById(inputId);
        if (passwordField.type === "password") {
            passwordField.type = "text";
        } else {
        passwordField.type = "password";
        }
    }
    