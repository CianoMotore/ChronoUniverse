<?php
   session_start();
   include("config.php");

   $redirect_link = isset($_SESSION['valid']) ? "area-personale.php" : "login.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
    <section id="header">
        <a href="index.php"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php" class="active">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="cart.php"><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=<?php echo $redirect_link; ?>><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="page-header" class="about-header">
        <h2>#KnowUs</h2>
        <p></p>
    </section>
    
    <section id="about-head" class="section-p1">
        <img src="IMG/a6.jpg" alt="">
        <div>
            <h2>Who We Are?</h2>
            <p>Siamo più di un semplice negozio di orologi di lusso. Siamo una comunità di appassionati che credono che ogni polso racconti una storia.

                I nostri esperti selezionano con cura orologi iconici, da Rolex senza tempo a Patek Philippe classici, per aiutarti a trovare il segnatempo che riflette la tua personalità.
                
                Affidabilità e cura sono la nostra promessa. Esplora il nostro universo e scopri il tuo orologio da eroe quotidiano.
                <br><br>Scopri l'universo di ChronoUniverse, dove il tempo incontra lo stile.
            </p>

            <!-- <abbr title="">Scopri l'universo di ChronoUniverse, dove il tempo incontra lo stile.</abbr> -->

            <br><br>
            <marquee style="background-color: #ccc" loop="-1" scrollamount="5" width="100%">per maggiori informazioni contatta: 4934994</marquee>

        </div>
    </section>

    <section id="about-app" class="section-p1">
        <h1>Download Our <a href="#">App</a></h1>
        <div class="video">
            <video autoplay muted loop src="IMG/1.mp4"></video>
        </div>
    </section>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script src="JS/script.js"></script>
</body>

</html>