<?php
   session_start();
   include("config.php");

   $redirect_link = isset($_SESSION['valid']) ? "area-personale.php" : "login.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php"  class="active">Contact</a></li>
                <li><a href="cart.php"><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=<?php echo $redirect_link; ?>><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="page-header" class="blog-header">
        <h2>#LetsTalk</h2>
        <p>LEAVE A MESSAGE, We love to hear form you </p>
    </section>

    <section id="contact-details" class="section-p1">
       <div class="details">
        <span>GET IN TOUCH</span>
        <h2>Visit one of our agency locations or contact us today</h2>
        <h3>Head Office</h3>
        <div>
            <li>
                <i class="fa fa-map"></i>
                <p>Vicenza Via Gallieno 52</p>
            </li>

            <li>
                <i class="fa fa-envelope"></i>
                <p>chronouniverse.info.@gov.com</p>
            </li>

            <li>
                <i class="fa fa-phone"></i>
                <p>3218312931820</p>
            </li>

            <li>
                <i class="fa fa-clock"></i>
                <p>Monday to Friday: 9:00 to 16:00</p>
            </li>
        </div>
       </div> 

       <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d179044.53807065455!2d11.314642265295383!3d45.47844705208044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477f33d34d35f2f5%3A0xda06b7b336c4e0b2!2sVia%20Legione%20Gallieno%2C%2052%2C%2036100%20Vicenza%20VI!5e0!3m2!1sit!2sit!4v1709846638643!5m2!1sit!2sit" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
       </div>
    </section>


    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

</body>
</html>