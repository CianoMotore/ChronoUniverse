<?php
    // Connessione al database
    session_start();
    include("config.php");

    // Query per ottenere gli ordini del cliente corrente
    $id_cliente = $_SESSION['valid'];

    // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
    if (isset($_SESSION['valid'])) {
        // Ottieni l'email del cliente dalla sessione
        $email_cliente = $_SESSION['valid'];
    
        // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
        $query = "SELECT * FROM Cliente WHERE email = ?";
    
        // Prepara la query
        $stmt = $conn->prepare($query);
    
        // Verifica se la query è stata preparata correttamente
        if ($stmt === false) {
            die("Errore di preparazione della query: " . $conn->error);
        }
    
        // Esegui il binding del parametro
        $stmt->bind_param("s", $email_cliente);

        // Esegui la query
        $stmt->execute();
    
        // Ottieni il risultato della query
        $result = $stmt->get_result();
    
        // Verifica se ci sono risultati
        if ($result->num_rows > 0) {
            // Output delle informazioni del cliente
            while ($row = $result->fetch_assoc()) {
                $name = $row['nome'];
                $surname = $row['cognome'];
                $birthDate= $row['data_nascita'];
                $email = $row['email'];
                $address= $row['indirizzo'];
                $phone = $row['recapito'];
                $password = $row['pwd'];
            }

            //"  . $_SERVER['PHP_SELF'] ."

            echo "<form action='"  . $_SERVER['PHP_SELF'] ."' method='post'>";
                echo '<i class="fas fa-user-circle icon"></i>';
                echo "<div class='flex'>";
                    echo "<div class='inputBox'>";
                        echo "<span> Nome:" ."</span>";
                        echo "<input type='text' name='update_name' value='$name' class='box'>";
                        echo "<span> Cognome:" ."</span>";
                        echo "<input type='text' name='update_surname' value='$surname' class='box'>";
                        echo "<span> La tua email" ."</span>";
                        echo "<input type='text' name='update_email' value='$email' class='box'>";
                    echo "</div>";
                    echo "<div class='inputBox'>";
                        echo "<input type='hidden' name='old_name' value='$password'>";
                        echo "<span> Clicca per vedere la Passowrd:" ."</span>";
                        echo "<input type='password' id='pass' name='pass' readonly value='$password' class='box' onclick=\"mostraPassword('pass')\">";
                        echo "<span> Nuova Password:" ."</span>";
                        echo "<input type='password' name='new_pass' placeholder='Nuova Password' class='box'>";
                        echo "<span> Conferma Password:" ."</span>";
                        echo "<input type='password' name='confirm_pass' placeholder='Conferma Password' class='box'>";
                    echo "</div>";
                echo "</div>";
                echo "<input type='submit' value='Aggiorna Profilo' name='update_profile' class='btn'>";
                // echo "<a href='index.php' class='delete-btn'>". "Aggiorna e Torna alla Home" ."</a>";    
            echo "</form>";

        } else {
            echo "<p>Nessuna informazione trovata.</p>";
        }
    
        // Chiudi la connessione al database
        $stmt->close();
    } else {
        // L'utente non è loggato o non ha un'email associata
        echo "<p>Si è verificato un errore nel recupero delle informazioni.</p>";
    }

    $stmt2 = null;

    if (isset($_POST['update_profile'])) {
        // Ottieni i dati inviati dal modulo
        $update_name = $_POST['update_name'];
        $update_surname = $_POST['update_surname'];
        $update_email = $_POST['update_email'];
        $update_pass = $_POST['update_pass'];
        $new_pass = $_POST['new_pass'];
        $confirm_pass = $_POST['confirm_pass'];

        // Controllo se la nuova password e la conferma password corrispondono
        

        if ($new_pass != $confirm_pass) {
            echo "<script>alert('Le password non corrispondono.'); window.location.href = 'index.php';</script>";
            exit(); // Assicurati di terminare lo script dopo aver inviato il redirect
        } else {
            // Costruisci la query di aggiornamento dinamicamente in base ai campi inviati
            $update_query = "UPDATE Cliente SET ";
            $params = array();
            if (!empty($update_name)) {
                $update_query .= "nome=?, ";
                $params[] = $update_name;
            }
            if (!empty($update_surname)) {
                $update_query .= "cognome=?, ";
                $params[] = $update_surname;
            }
            if (!empty($update_email)) {
                $update_query .= "email=?, ";
                $params[] = $update_email;
            }
            if (!empty($new_pass) && !empty($confirm_pass) && $new_pass == $confirm_pass) {
                $update_query .= "pwd=?, ";
                $params[] = $new_pass;
            }
            // Rimuovi l'ultima virgola e lo spazio
            $update_query = rtrim($update_query, ", ");
            
            // Aggiungi la clausola WHERE per identificare l'utente
            $update_query .= " WHERE email=?";
            $params[] = $_SESSION['valid'];
    
            // Esegui l'aggiornamento del profilo dell'utente nel database
            $stmt2 = $conn->prepare($update_query);
            $types = str_repeat("s", count($params)); // Calcola il tipo dei parametri
            $stmt2->bind_param($types, ...$params);
            if ($stmt2->execute()) {
                echo "Profilo aggiornato con successo.";
                // Aggiorna i valori di sessione con i nuovi dati, se l'email è stata modificata
                if (!empty($update_email)) {
                    $_SESSION['valid'] = $update_email;
                }
            } else {
                echo "Si è verificato un errore durante l'aggiornamento del profilo.";
            }
        }
    }
    
    // Chiudi la connessione al database
    if ($stmt2 !== null) {
        $stmt2->close();
    }
    $conn->close();
    echo "<script>window.location.href = 'area-personale.php';</script>";
    // header("Location: index.php")
    // exit;

    // $query_update_name = ;
    // $stmt2 = $conn->prepare($query_update_name);
    // if ($stmt2 === false) {
    //     die("Errore di preparazione della query: " . $conn->error);
    // }
    // $stmt2->bind_param("s", $email_cliente);
    // $stmt2->execute();
?>