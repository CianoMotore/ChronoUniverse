<?php
    session_start();
    include("config.php");
    
    // Verifica la connessione al database
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = $_SESSION['valid'];

        // Query SQL per selezionare l'indirizzo in base all'email
        $sql = "SELECT indirizzo FROM indirizzo WHERE email = '$email'";

        // Eseguire la query nel database
        $result = mysqli_query($conn, $sql);

        // Verificare se la query ha avuto successo
        if ($result) {
            // Estrai i risultati della query
            while ($row = mysqli_fetch_assoc($result)) {
                $indirizzo = $row['indirizzo'];
            }
        } 

        $sql= "INSERT INTO ordine (data_ordine, stato, data_consegna, costo_spedizione, data_spedizione, corriere, indirizzo_spedizione, codice_cliente) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $data_ordine = date('Y-m-d H:i:s');
        $data_consegna = date('Y-m-d H:i:s');
        $costo_spedizione = 5.00;
        $data_spedizione = date('Y-m-d H:i:s');
        $corriere = 'dhl';
        $codice_cliente = $email;
        $stato = 'In Elaborazione';

        $stmt->bind_param("sssdssss", $data_ordine, $stato, $data_consegna, $costo_spedizione, $data_spedizione, $corriere, $indirizzo, $codice_cliente);
        $stmt->execute();
        if ($stmt->error) {
            echo "Errore: " . $stmt->error . "<br>";
        }

        $stmt->close();

        $cartData = json_decode($_COOKIE['cart'], true);
        $cartItems = '';

        $sqlId = "SELECT id_ordine FROM ordine WHERE codice_cliente = '$email'";

        $result = $conn->query($sqlId);

        if ($result->num_rows > 0) {
            // Estrai l'ultimo id_ordine
            $row = $result->fetch_assoc();
            $id_ordine = $row["id_ordine"];
            // Loop per inserire i dettagli dell'ordine
            foreach ($cartData as $item) {

                $sqlDettaglioOrdine = "INSERT INTO dettaglioordine (codice_ordine, descrizione, prezzo, iva, quantità, codice_orologio) 
                VALUES (?, ?, ?, ?, ?, ?)";
                // Prepara la query SQL
                $stmt2 = $conn->prepare($sqlDettaglioOrdine);
            if ($stmt2) {
                $orologio = 'Orologio';
                $iva = '22%';
                // Associa i parametri alla query preparata
                $stmt2->bind_param("ssssss", $id_ordine, $orologio, $price, $iva, $quantity, $productId);
                // Esegui la query
                $result2 = $stmt2->execute();
                if ($result2) {
                    unset($_COOKIE['cart']);
                    header("LOCATION: index.php");
                } else {
                    // Gestione dell'errore durante l'inserimento dei dettagli dell'ordine
                    echo "Errore durante l'inserimento dei dettagli dell'ordine: " . $stmt2->error;
                }
            } else {
                // Gestione dell'errore durante la preparazione della query
                echo "Errore durante la preparazione della query: " . $conn->error;
            }
        }
        } else {
            // Gestione dell'errore nel caso in cui non sia stato trovato alcun ID ordine
            echo "Nessun ID ordine trovato.";
        }
        
            
    }        
?>