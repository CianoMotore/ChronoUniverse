<?php
    session_start();
    include("config.php");
    
    // Verifica la connessione al database
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = $_SESSION['valid']; // Ottenere il valore dell'email dal cookie

        // Query SQL per selezionare l'indirizzo in base all'email
        $sql = "SELECT indirizzo FROM indirizzo WHERE email = '$email'";

        // Eseguire la query nel database
        $result = mysqli_query($conn, $sql);

        // Verificare se la query ha avuto successo
        if ($result) {
            // Estrai i risultati della query
            while ($row = mysqli_fetch_assoc($result)) {
                // Utilizza $row['indirizzo'] per accedere all'indirizzo trovato
                $indirizzo = $row['indirizzo'];
                // Fai qualcosa con l'indirizzo trovato...
            }
        } 

        $sql= "INSERT INTO ordine (data_ordine, stato, costo_spedizione, corriere, indirizzo_spedizione, codice_cliente)	
        ) VALUES (?, ?, ?, ?,?, ?,?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", date('Y-m-d H:i:s'), 'In Elaborazione', 5.00, 'dhl', $indirizzo, $email);

        $cartData = json_decode($_COOKIE['cart'], true);
        
          // Initialize variables
        $cartItems = '';

        $sql = "SELECT id_ordine 
        FROM ordine 
        ORDER BY id_ordine DESC 
        LIMIT 1";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Estrai l'ultimo id_ordine
            $row = $result->fetch_assoc();
            $id_ordine = $row["id_ordine"];
        }

        foreach ($cartData as $item) {
            $productId = $item['id_orologio'];
            $image = $item['immagine']; // Assuming you have an 'image' key in the product array
            $price = $item['prezzo'];
            $quantity = $item['quantità'];
            $brand = $item['marca'];
            $model = $item['modello'];



            $sql = "INSERT INTO dettaglioordine (descrizione, prezzo, iva, quantità, codice_orologio, codice_ordine	) 
                    VALUES (?, ?, ?, ?, ?, ?)";
    
            // Prepara la query SQL
            $stmt = $conn->prepare($sqlDettaglioOrdine);
            if ($stmt) {
                // Associa i parametri alla query preparata
                $stmt->bind_param("ssssss", 'Orologio', $price, '22%', $quantity, $productId, $id_ordine);

                // Esegui la query
                $result = $stmt->execute();

            }
        }

        unset($_COOKIE['cart']);

        header("LOCATION: index.php");
            
    }


        
?>