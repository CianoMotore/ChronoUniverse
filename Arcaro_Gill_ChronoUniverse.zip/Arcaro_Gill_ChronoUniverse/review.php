<?php
    session_start();
    include("config.php");
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if(isset($_POST['review']) && isset($_POST['rating']) && isset($_POST['titolo'])){
    
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "INSERT INTO recensione (valutazione, titolo, commento, data_recensione, email, cod_orologio) 
                VALUES (?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $POST['rating'], $POST['review_title'], $POST['review'], date('Y-m-d H:i:s'), $_SESSION['valid'], $_COOKIE['id_orologio']);

            $stmt->execute();

            header('Location: index.php');
        }else{
            header('Location: index.php');
        }
    }
?>