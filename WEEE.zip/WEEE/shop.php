<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
    <section id="header">
        <a href="#"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php" class="active">Shop</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="cart.php"><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=""><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="page-header">
        <h2>#stayhome</h2>
        <p>Save more with coupons & up to 70% off!</p>
        
    </section>
    
    <?php
    
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dbecommerce";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_POST['type'])) {
            $type = $conn->real_escape_string($_POST['type']);
        } else {
            $type = "";
        }
        
        if (!isset($_POST['type'])) {

            // Define the SQL query to fetch 16 products
            $sql = 'SELECT id_orologio, marca, modello, immagine, prezzo FROM prodotto ORDER BY RAND() LIMIT 16';

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                DisplayHtml($result);
                /*echo "<form action='sproduct.php' method='POST'>";
                echo "<section id='product1' class='section-p1'>";
                echo "<h2>Featured Products</h2>";
                echo "<p>Gill Collection New Morden Design</p>";

                while($row = $result->fetch_assoc()) {
                    $product_brand = $row['marca'];
                    $product_image = base64_encode($row['immagine']);
                    $product_price = $row['prezzo'];
                    $product_model = $row['modello'];
                    $product_id = $row['id_orologio'];
                
                    echo "<input type='hidden' name='id_orologio' value='$row['id_orologio']'>";  
                    echo "<div class='pro-container'>";
                    echo "<div class='pro'>";
                    echo "<input type='submit'><img src='$product_image' alt='$product_brand.$product_model'>";
                    echo "<div class='des'>";
                    echo "<span>$product_brand</span>";
                    echo "<h5>$product_brand.$product_model</h5>"; 
                    echo "<div class='star'>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "</div>";
                    echo "<h4>$$product_price</h4>";
                    echo "</div>";
                    echo "<button class='add-to-cart-btn' product-id='$row['id_orologio']>'><i class='fa fa-shopping-cart cart'></i></button>";
                    echo "<a href='#'><i class='fa fa-heart-o heart'></i></a>";
                    echo "</div>";
                    echo "</div>";
                }

                
                echo "</section>";
                echo "</form>";*/
            }else {
                echo "No featured products found for the selected type.";
            }
        }
        else{
            $sql = "SELECT id_orologio, marca, modello, immagine, prezzo FROM products WHERE ";

            if (strpos($type, " ") !== false) { // Check if type contains space (brand model)
                list($brand, $model) = explode(" ", $type); // Separate brand and model using space
                $sql .= "(brand = ? AND model = ?) LIMIT 16";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $brand, $model);
            } else {
                $sql .= "(brand = ? OR model = ?) LIMIT 16";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $type, $type);
            }

            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                DisplayHtml($result);
                /*echo "<form action='sproduct.php' method='POST'>";
                echo "<section id='product1' class='section-p1'>";
                echo "<h2>Featured Products</h2>";
                echo "<p>Gill Collection New Morden Design</p>";
                

                while($row = $result->fetch_assoc()) {
                    $product_brand = $row['marca'];
                    $product_image = $row['immagine'];
                    $product_price = $row['prezzo'];
                    $product_model = $row['modello'];
                    $product_id = $row['id_orologio'];
                
                    echo "<input type='hidde' name='id_orologio' value='$product_id'>";  
                    echo "<div class='pro-container'>";
                    echo "<div class='pro'>";
                    echo " <input type='submit'><img src='$product_image' alt=''>";
                    echo "<div class='des'>";
                    // Assuming both brand and model are stored
                    echo "<span>$product_name</span>"; 
                    echo "<h5>$row[brand]. $row[model]</h5>";  // Display brand and model with space
                    echo "<div class='star'>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "<i class='fa fa-star'></i>";
                    echo "</div>";
                    echo "<h4>$$product_price</h4>";
                    echo "</div>";
                    echo "<a href='#'><i class='fa fa-shopping-cart cart'></i></a>";
                    echo "</div>";
                    echo "</div>";
                }

                echo "</section>";
                echo "</form>";*/
            } else {
                echo "No featured products found for the selected type.";
            }
        }

        function DisplayHtml($result){
            echo "<form action='sproduct.php' method='POST'>";
            echo "<section id='product1' class='section-p1'>";
            echo "<h2>Featured Products</h2>";
            echo "<p>Gill Collection New Morden Design</p>";

            while($row = $result->fetch_assoc()) {
                $product_brand = $row['marca'];
                $product_image = base64_encode($row['immagine']);
                $product_price = $row['prezzo'];
                $product_model = $row['modello'];
                $product_id = $row['id_orologio'];
            
                echo "<input type='hidden' name='id_orologio' value='$product_id'>";  
                echo "<div class='pro-container'>";
                echo "<div class='pro'>";
                echo "<input type='submit'><img src='$product_image' alt='$product_brand.$product_model'>";
                echo "<div class='des'>";
                echo "<span>$product_brand</span>";
                echo "<h5>$product_brand.$product_model</h5>"; 
                echo "<div class='star'>";
                echo "<i class='fa fa-star'></i>";
                echo "<i class='fa fa-star'></i>";
                echo "<i class='fa fa-star'></i>";
                echo "<i class='fa fa-star'></i>";
                echo "<i class='fa fa-star'></i>";
                echo "</div>";
                echo "<h4>$$product_price</h4>";
                echo "</div>";
                echo "<button class='add-to-cart-btn' product-id='$product_id>'><i class='fa fa-shopping-cart cart'></i></button>";
                echo "<a href='#'><i class='fa fa-heart-o heart'></i></a>";
                echo "</div>";
                echo "</div>";
            }

            
            echo "</section>";
            echo "</form>";
        }
        
        $conn->close();

    ?>

    <section id="pagination" class="section-p1">
        <a href="#">1</a>
        <a href="#">2</a>
        <a href="#"><i class="fa fa-arrow-right"></i></a>
    </section>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script>
        $(document).ready(function() {
            $('.add-to-cart-btn').click(function(event) {
                event.preventDefault(); // Prevent the default action of the button

                // Get the product ID from the data attribute of the button
                var productId = $(this).data('product-id');
                var quantity = 1;


                // AJAX request to add the product to the cart
                $.ajax({
                    type: 'POST',
                    url: 'add-to-cart.php',
                    data: {id_orologio: productId, quantità: quantity},
                    dataType: 'json',
                    success: function(response) {
                        // Handle success response
                        if (response.success) {
                            alert('Product added to cart successfully!');
                            // Optionally, you can update the cart icon or perform any other action
                        } else {
                            alert('Error adding product to cart. Please try again.');
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle error response
                        console.error(xhr.responseText); // Log error response for debugging
                        alert('Error adding product to cart. Please try again.');
                    }
                });
            });
        });
    </script>

    <script src="JS/script.js"></script>
</body>

</html>