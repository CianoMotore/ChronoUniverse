<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbecommerce";

$conn = mysqli_connect($servername, $username, $password, $database) or die ("Connessione al server non riuscita");
?>