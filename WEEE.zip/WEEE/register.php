<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/login-style.css">
    <title>ChronoUniverse Sign Up</title>
</head>
<body>
    <div class="container">
        <div class="box form-box">

            <?php
                include("config.php");

                if(isset($_POST["submit"])) {
                    $name = $_POST["name"];
                    $surname = $_POST["surname"];
                    $birthDate = $_POST["birthDate"];
                    $email = $_POST["email"];
                    $address = $_POST["address"];
                    $phone = $_POST["phone"];
                    $password = $_POST["password"];
                
                    // Query per verificare se l'email è già stata usata
                    $check_email_query = "SELECT * FROM cliente WHERE email = ?";
                    $check_stmt = $conn->prepare($check_email_query);
                    $check_stmt->bind_param("s", $email);
                    $check_stmt->execute();
                    $check_result = $check_stmt->get_result();
                
                    if ($check_result->num_rows > 0) {
                        echo "<script>alert('Questa email è già stata utilizzata. Si prega di scegliere un\'altra email.');</script>";
                        echo "<script>window.location = 'register.php';</script>";
                        exit(); // Termina lo script
                    } else {
                        // Inserimento nel database
                        $sql = "INSERT INTO cliente (email, nome, cognome, data_nascita, indirizzo, pwd, recapito) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("sssssss", $email, $name, $surname, $birthDate, $address, $password, $phone);
                        $stmt->execute();
                        
                        // Verifica degli errori
                        if ($stmt->error) {
                            echo "Errore: " . $stmt->error . "<br>";
                        } else {
                            echo "Registrazione avvenuta con successo!<br>";
                            echo "<button class='btn'><a href='login.php' style='text-decoration: none'>Accedi Ora</a></button>";
                        }
                
                        $stmt->close();
                    }
                } else {
            ?>

            <header>Sign Up</header>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"  method="post">
                <div class="field input">
                    <input type="text" name="name" id="name" autocomplete="off" placeholder="Nome" required>
                </div>
                
                <div class="field input">
                    <input type="text" name="surname" id="surname" autocomplete="off" placeholder="Cognome" required>
                </div>

                <div class="field input">
                    <input type="text" name="birthDate" id="birthDate" placeholder="Data di Nascita" onfocus="(this.type='date')" onblur="(this.type='text')" required>
                </div>

                <div class="field input">
                    <input type="email" name="email" id="email" autocomplete="off" placeholder="Email" required>
                </div>

                <div class="field input">
                    <input type="text" name="address" id="address" autocomplete="off" placeholder="Indirizzo" required>
                </div>

                <div class="field input">
                    <input type="text" name="phone" id="phone" autocomplete="off" placeholder="Telefono" required>
                </div>

                <div class="field input">
                    <input type="password" name="password" id="password" autocomplete="off" placeholder="Password" required>
                </div>

                <div class="field">
                    <input type="submit" name="submit" class="btn" value="Sign Up">
                </div>

                <div class="links">
                    Hai già un account ? <a href="login.php">Log In</a>
                </div>
            </form>
        </div>
        <?php }?>
    </div>
</body>
</html>