<?php
    // Connessione al database
    session_start();
    include("config.php");

    // Query per ottenere gli ordini del cliente corrente
    $id_cliente = $_SESSION['valid'];

    // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
    if (isset($_SESSION['valid'])) {
        // Ottieni l'email del cliente dalla sessione
        $email_cliente = $_SESSION['valid'];
    
        // Query per ottenere gli ordini del cliente corrente con informazioni del prodotto associato
        $query = "SELECT * FROM Cliente WHERE email = ?";
    
        // Prepara la query
        $stmt = $conn->prepare($query);
    
        // Verifica se la query è stata preparata correttamente
        if ($stmt === false) {
            die("Errore di preparazione della query: " . $conn->error);
        }
    
        // Esegui il binding del parametro
        $stmt->bind_param("s", $email_cliente);
    
        // Esegui la query
        $stmt->execute();
    
        // Ottieni il risultato della query
        $result = $stmt->get_result();
    
        // Verifica se ci sono risultati
        if ($result->num_rows > 0) {
            // Output delle informazioni del cliente
            echo '<div class="user-info">';
            while ($row = $result->fetch_assoc()) {
                echo '<div class="info-item"><span>Email:</span>' . $row['email'] . '</div>';
                echo '<div class="info-item"><span>Nome:</span>' . $row['nome'] . '</div>';
                echo '<div class="info-item"><span>Cognome:</span>' . $row['cognome'] . '</div>';
                echo '<div class="info-item"><span>Data di Nascita:</span>' . $row['data_nascita'] . '</div>';
                echo '<div class="info-item"><span>Indirizzo:</span>' . $row['indirizzo'] . '</div>';
                echo '<div class="info-item"><span>Recapito:</span>' . $row['recapito'] . '</div>';
            }
            echo '</div>';
        } else {
            echo "<p>Nessuna informazione trovata.</p>";
        }
    
        // Chiudi la connessione al database
        $stmt->close();
        $conn->close();
    } else {
        // L'utente non è loggato o non ha un'email associata
        echo "<p>Si è verificato un errore nel recupero delle informazioni.</p>";
    }
?>