<?php

// Includi la libreria per il parsing HTML
include('simple_html_dom.php');

// Connessione al database MySQL
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "nome_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// URL della pagina da cui estrarre i dati
$url = "https://www.chrono24.it/search/watch-explorer.htm";

// Esegui il parsing HTML della pagina
$html = file_get_html($url);

// Estrai i dati e inseriscili nel database
foreach($html->find('div.prodotto') as $prodotto) {
    $modello = $prodotto->find('h2', 0)->plaintext;
    $movimento = $prodotto->find('.movimento', 0)->plaintext;
    $materiale_cassa = $prodotto->find('.materiale_cassa', 0)->plaintext;
    $diametro_cassa = $prodotto->find('.diametro_cassa', 0)->plaintext;
    $colore_quadrante = $prodotto->find('.colore_quadrante', 0)->plaintext;
    $impermeabilita = $prodotto->find('.impermeabilita', 0)->plaintext;
    $funzioni = $prodotto->find('.funzioni', 0)->plaintext;
    $prezzo = $prodotto->find('.prezzo', 0)->plaintext;
    $immagine = $prodotto->find('img', 0)->src;
    $categoria = "orologio"; // Categoria predefinita

    // SQL di inserimento dei dati nella tabella prodotto
    $sql = "INSERT INTO prodotto (modello, movimento, materiale_cassa, diametro_cassa, colore_quadrante, impermeabilita, funzioni, prezzo, immagine, categoria) 
            VALUES ('$modello', '$movimento', '$materiale_cassa', '$diametro_cassa', '$colore_quadrante', '$impermeabilita', '$funzioni', '$prezzo', '$immagine', '$categoria')";

    if ($conn->query($sql) === TRUE) {
        echo "Record inserito con successo";
    } else {
        echo "Errore nell'inserimento del record: " . $conn->error;
    }
}

// Chiudi la connessione al database
$conn->close();

?>
