<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <section id="header">
        <a href="#"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php" >Home</a></li>
                <li><a href="shop.php" class="active">Shop</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href=""><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href="login.php"><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <?php
        //session_start();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dbecommerce";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $fruits = array("apple" => "verde", "banana" => "giallo", "orange" => "arancione");

        foreach ($_POST as $name=> $id) {
            $id = $name;
            break;
        }

        $id_orologio = isset($_POST[$id]) ? $_POST[$id] : $_COOKIE['id_orologio'];


        $sql = "SELECT * FROM prodotto WHERE id_orologio = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $id_orologio);
        $stmt->execute();

        // Get result
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $img = $row['immagine'];
            $marca = $row['marca'];
            $modello = $row['modello'];
            $prezzo = $row['prezzo'];
            $id_orlogio = $row['id_orologio'];
            $materiale_cassa = $row['materiale_cassa'];
            $movimento = $row['movimento'];
            $impermeabilita = $row['impermeabilità'];
            $diametro_cassa = $row['diametro_cassa'];
            $colore_quadrante = $row['colore_quadrante'];
            $funzioni = $row['funzioni'];
            // Display product details section
            echo "<section id='prodetails' class='section-p1'>";

            echo "<div class='single-pro-image'>";
            echo "  <img src='$img' alt='' width='100%' id='MainImg'>";
            echo "  <div class='small-img-group'>";
            echo "  </div>";
            echo "</div>";
            echo "<div class='single-pro-details'>";
            echo "  <h6>Shop / $marca</h6>";
            echo "  <h4>$modello</h4>";
            echo "  <h2>&#36;$prezzo</h2>";
            echo "  <input type='number' value='1' name='quantità' id='quantità'>";
            echo "  <button class='add-to-cart-btn' data-product-id='$id_orologio'>Add to Cart</button>";
            echo "  <h4>Product Details</h4>";
            echo "  <span>";
            echo "Case Material: $materiale_cassa<br>";
            echo "Movement Type: $movimento<br>";
            echo "Water Resistance: $impermeabilita<br>";
            echo "Case Diameter (mm): $diametro_cassa<br>";
            echo "Dial Color: $colore_quadrante<br>";
            echo "Complications: $funzioni<br>";
            echo "</span>";
            echo "</div>";
            echo "</section>";
        }

        $_COOKIE['id_orologio'] = $id_orlogio;

        $sql = "SELECT * FROM recensione WHERE codice_orologio = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $id_orologio);
        $stmt->execute();

        // Get result
        $result = $stmt->get_result();

        echo "<div id='review-section'>";
        echo "<h2>Reviews and Ratings</h2>";

        if ($result->num_rows > 0) {

            echo "  <div id='existing-reviews'>";
            while ($review_row = $result->fetch_assoc()) {

                $reviewer_titolo = $review_row['titolo'];
                $review_comment = $review_row['commento'];
                $review_rating = $review_row['voto'];

                echo "    <div class='review'>";
                echo "      <p>$reviewer_titolo</p>";
                echo "      <p>$review_comment</p>";
                echo "      <p>Rating: $review_rating stars</p>";
                echo "    </div>";
            }
            echo "  </div>";

        } else {
            echo "  <div id='existing-reviews'>";
            echo "    <p>No reviews yet. Be the first to write one!</p>";
            echo "  </div>";
        }
        
        $conn->close();
        
    ?>

<!--<div id="review-section">
  <h2>Reviews and Ratings</h2>
  <div id="existing-reviews">
    <p>No reviews yet. Be the first to write one!</p>
  </div>-->
  <div id="submit-review">
    <h3>Write a Review</h3>
    <form action="review.php" method="POST" id="review-form">
        <div>
            <label for="review-title">Review Title:</label>
            <input type="text" name="titolo" id="title" placeholder="Enter your review title">
        </div>
      <textarea name="review" placeholder="Write your review here..."></textarea>
      <div class="star-rating">
        <label for="star-5" aria-label="Rating of 5 stars"><i class="fas fa-star"></i></label>
        <input type="radio" id="star-5" name="rating" value="5">
        <label for="star-4" aria-label="Rating of 4 stars"><i class="fas fa-star"></i></label>
        <input type="radio" id="star-4" name="rating" value="4">
        <label for="star-3" aria-label="Rating of 3 stars"><i class="fas fa-star"></i></label>
        <input type="radio" id="star-3" name="rating" value="3">
        <label for="star-2" aria-label="Rating of 2 stars"><i class="fas fa-star"></i></label>
        <input type="radio" id="star-2" name="rating" value="2">
        <label for="star-1" aria-label="Rating of 1 star"><i class="fas fa-star"></i></label>
        <input type="radio" id="star-1" name="rating" value="1">
      </div>
      <button type="submit">Submit Review</button>
    </form>
  </div>
</div>


    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script>
        $(document).ready(function() {
            $('.add-to-cart-btn').click(function(event) {
                event.preventDefault(); // Prevent the default action of the button

                // Get the product ID from the data attribute of the button
                var productId = $(this).data('product-id');
                var quantity = $('#quantità').val();

                // AJAX request to add the product to the cart
                $.ajax({
                    type: 'POST',
                    url: 'add-to-cart.php',
                    data: {id_orologio: productId, quantità: quantity},
                    dataType: 'json',
                    success: function(response) {
                        // Handle success response
                        if (response.success) {
                            alert('Product added to cart successfully!');
                            // Optionally, you can update the cart icon or perform any other action
                        } else {
                            alert('Error adding product to cart. Please try again.');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText); // Log error response for debugging
                        alert('Error adding product to cart. Please try again.');
                    }
                });
            });
        });
    </script>


    <script src="JS/script.js"></script>
</body>

</html>