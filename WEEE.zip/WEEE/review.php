<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if(isset($POST['review']) && isset($POST['rating']) && isset($POST['title'])){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "dbecommerce";
    
            // Create connection
            $conn = new mysqli($servername, $username, password, $dbname);
    
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "INSERT INTO recensione (valutazione, titolo, commento, data_recensione, email, cod_orologio) 
                VALUES (?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $POST['rating'], $POST['review_title'], $POST['review'], date('Y-m-d H:i:s'), $_COOKIE['valid'], $_COOKIE['id_orologio']);

            $stmt->execute();

            header('Location:sproduct.php');
        }
    }
?>