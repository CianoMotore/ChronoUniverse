<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbeccomerce";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Verifica la connessione al database
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $sql= "INSERT INTO ordine (data_ordine, stato, ... altri campi) VALUES (?, ?, ...)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss...", date('Y-m-d H:i:s'), $stato, ...);
        $stmt->execute();
    }
?>