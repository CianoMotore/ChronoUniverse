<?php
    // Perform the removal of the product from the cart
    if (isset($_GET['id'])) {
        $productIdToRemove = $_GET['id'];
        $cartData = json_decode($_COOKIE['cart'], true);

        // Remove the item from the cart data
        foreach ($cartData as $key => $item) {
            if ($item['id_orologio'] == $productIdToRemove) {
                unset($cartData[$key]);
                break;
            }
        }
        
        // Re-encode cart data and update cookie
        setcookie('cart', json_encode($cartData), time() + (86400 * 30), '/'); // Set cookie expiration for 30 days
        $cartHtml = generateCartHtml();

        // Invia la risposta JSON
        echo json_encode(array(
            'success' => true,
            'cartHtml' => $cartHtml
        ));
        exit();
    } else {
        // Handle invalid request
        echo 'Invalid request';
        exit();
    }

    function generateCartHtml() {
        $cartData = json_decode($_COOKIE['cart'], true);
        $cartItems = '';
        $total = 0;

        foreach ($cartData as $item) {
            $productId = $item['id_orologio'];
            $image = $item['immagine'];
            $price = $item['prezzo'];
            $quantity = $item['quantità'];
            $brand = $item['marca'];
            $model = $item['modello'];
            $subtotal = $price * $quantity;
            $total += $subtotal;
            $cartItems .= "<tr>
                                    <td><a href='remove-from-cart.php?id=$productId'><i class='fa fa-times'></i></a></td>
                                    <td><img src='$image' alt='$brand $model'></td>
                                    <td>$brand $model</td>
                                    <td>$price €</td>
                                    <td><input type='number' value='$quantity' name='quantity[$productId]' readonly></td>
                                    <td>$subtotal €</td>
                                </tr>";
        }
        
        // Build the final HTML for the cart section
        $cartSection = "<table width='100%'>
                                <thead>
                                    <tr>
                                        <td>Remove</td>
                                        <td>Image</td>
                                        <td>Product</td>
                                        <td>Price</td>
                                        <td>Quantity</td>
                                        <td>Subtotal</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    $cartItems
                                </tbody>
                            </table>";
        
        return $cartSection;
    }
?>
