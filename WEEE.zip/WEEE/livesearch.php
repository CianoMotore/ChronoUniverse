<?php
include("config.php");
if(isset($_POST['input'])){
    $input = $_POST['input'];
    $query = "SELECT DISTINCT(modello), marca FROM prodotto WHERE modello LIKE '{$input}%' OR marca LIKE '{$input}%' LIMIT 3";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            $marca = $row['marca'];
            $modello = $row['modello'];
            // Output dei risultati con un attributo data-modello
            echo "<div class='search-result' data-modello='$modello'>$marca - $modello</div>";
        }
    } else {
        echo "<div class='search-result'>Nessun risultato trovato</div>";
    }
}
?>