<?php
   session_start();
   include("config.php");

   $redirect_link = isset($_SESSION['valid']) ? "area-personale.php" : "login.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <section id="header">
        <a href="#"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="#" class="active"><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=<?php echo $redirect_link; ?>><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <?php

        if (!isset($_COOKIE['cart'])) {
            return 'Your cart is empty.'; // Display empty cart message
          }
        
          // Decode the JSON-encoded cart data from the cookie
          $cartData = json_decode($_COOKIE['cart'], true);
        
          // Initialize variables
          $cartItems = '';
          $total = 0;
        
          // Loop through each product in the cart
          foreach ($cartData as $item) {
            $productId = $item['id_orologio'];
            $image = $item['immagine']; // Assuming you have an 'image' key in the product array
            $price = $item['prezzo'];
            $quantity = $item['quantità'];
            $brand = $item['marca'];
            $model = $item['modello'];
            $subtotal = $price * $quantity;
            $total += $subtotal;
            $t =true;
        
            // Build the table row for each product
            $cartItems .= "<tr>
                            <td><a href='#' class='remove-item' product-id='$productId'><i class='fa fa-times'></i></a></td>
                            <td><img src='$image' alt='$brand $model'></td>
                            <td>$brand $model</td>
                            <td>$price €</td>
                            <td><input type='number' value='$quantity' name='quantità' readonly=$t></td>
                            <td>$subtotal €</td>
                        </tr>";
          }
        
          // Build the final HTML for the cart section
          $cartSection = "  <form action='order.php method='POST'>
                                <section id='cart' class='section-p1'>
                                <table width='100%'>
                                    <thead>
                                        <tr>
                                            <td>Remove</td>
                                            <td>Image</td>
                                            <td>Product</td>
                                            <td>Price</td>
                                            <td>Quantity</td>
                                            <td>Subtotal</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        $cartItems
                                    </tbody>
                                </table>
                                </section>";
            echo $cartSection;
    ?>

    <!--<section id="cart" class="section-p1">
        <table width="100%">
            <thead>
                <tr>
                    <td>Remove</td>
                    <td>Image</td>
                    <td>Product</td>
                    <td>Price</td>
                    <td>Quantity</td>
                    <td>Subtotal</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><a href=""><i class="fa fa-"></i></a></td>
                    <td><img src="" alt=""></td>
                    <td>marca modello</td>
                    <td>prezzo</td>
                    <td><input type="number" value=""name="" id=""></td>
                    <td>subtotale</td>
                </tr>
            </tbody>
        </table>
    </section>-->

        <section id="cart-add" class="section-p1">
            <div id="coupon">
                <h3>Apply Coupon</h3>
                <div>
                    <input type="text" name="" id="" placeholder="Enter Your Coupon">
                    <button class="normal">Apply</button>
                </div>
            </div>
            <div id="subtotal">
                <h3>Cart Total</h3>
                <table>
                    <tr>
                        <td>Cart Subtotal</td>
                        <td><?php $total?></td>
                    </tr>
                    <tr>
                        <td>Shipping</td>
                        <td>Free</td>
                    </tr>

                    <tr>
                        <td><strong>Total</strong></td>
                        <td><strong><?php $total?></strong></td>
                    </tr>
                </table>
            </div>
            <button class="normal">Proceed to checkout</button>
        </section>
    </form>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script>
        $(document).ready(function() {
            $('.remove-item').click(function(event) {
                event.preventDefault(); // Prevent the default action of clicking on a link

                var productId = $(this).data('product-id'); // Get the product ID from the data attribute
                var removeUrl = 'remove-from-cart.php?id=' + productId; // URL to remove-from-cart.php

                $.ajax({
                    type: 'GET',
                    url: removeUrl,
                    success: function(response) {
                        // Handle success response
                        console.log(response); // Log response for debugging
                        updateCartDisplay(response); // Update cart display with the updated data
                    },
                    error: function(xhr, status, error) {
                        // Handle error response
                        console.error(xhr.responseText); // Log error response for debugging
                        // Example: Display an error message to the user
                        alert('Error removing product from cart. Please try again.');
                    }
                });
             });

            // Function to update the cart display
            function updateCartDisplay(cartHtml) {
                // Replace the existing cart section with the updated HTML
                $('#cart').html(cartHtml);
            }
        });
    </script>

    <script src="JS/script.js"></script>
</body>

</html>