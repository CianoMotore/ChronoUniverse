<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChronoUniverse Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
</head>

<body>
    <section id="header">
        <a href="#"><img src="IMG/logo.png" class="logo" width="10%" alt="logo"></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php" class="active">Shop</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href=""><i class="fa fa-shopping-cart"></i></a></li>
                <li><a href=""><i class="fa fa-user"></i></a></li>
            </ul>
        </div>
    </section>

    <section id="page-header">
        <h2>#stayhome</h2>
        <p>Save more with coupons & up to 70% off!</p>
    </section>

    <section  id="product1" class="section-p1">
        <h2 >Featured Products</h2>
        <p>Gill Collection New Morden Design</p>
        <div class="pro-container">
            <div class="pro">
                <img src="" alt="">
                <div class="des">
                    <span>rolex</span>
                    <h5>Orologio</h5>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <h4>prezzo</h4>
                </div>
                <a href="#"><i class="fa fa-shopping-cart cart"></i></a>
            </div>
        </div>
    </section>

    <section id="pagination" class="section-p1">
        <a href="#">1</a>
        <a href="#">2</a>
        <a href="#"><i class="fa fa-arrow-right"></i></a>
    </section>

    <footer class="section-p1">
        <hr>
        <div class="col">
            <!-- <img src="IMG/logo.png" alt="logo" width="10%"> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> 562 Wellington road, Street 32, San Francisco</p>
            <p><strong>Phone:</strong> +01 2222 365 / (+91) 01 2345 6789</p>

            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-x"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>

        <div class="col">
            <h4>Modalità di pagamento</h4>
            <!-- <img src="IMG/visa.jpg" alt="visa">
            <img src="IMG/mastercard.png" alt="mastercard">
            <img src="IMG/maestro.png" alt="maestro"> -->
            <img src="IMG/payment.jpg" alt="pagamenti">
        </div>

        <div class="copyright">
            <p>© 1969-2024 ChronoUniverse.com, Inc. o società affiliate</p>
        </div>
    </footer>

    <script src="JS/script.js"></script>
</body>

</html>