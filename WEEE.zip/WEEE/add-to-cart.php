<?php
    if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        if (isset($_POST['id_orologio'])) {

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "dbecommerce";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Get product ID from the AJAX request
            $productId = $_POST['id_orologio'];
            $quantità = $_POST['quantità'];

            $sql = "SELECT * FROM prodotto WHERE id_orologio = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $productId);
            $stmt->execute();


            // Get result
            $result = $stmt->get_result();

            if ($result->num_rows > 0){
                $row = $result->fetch_assoc();

                $productDetails = array(
                    'id_orologio' => $productId,
                    'immagine' => $row['immagine'], 
                    'prezzo' => $row['prezzo'], 
                    'quantità' => $quantità, 
                    'marca' => $row['marca'],
                    'modello' => $row['modello']
                );

                // Add the product details to the cart array stored in the cookie
                $cartData = isset($_COOKIE['cart']) ? json_decode($_COOKIE['cart'], true) : array(); 
                $cartData[] = $productDetails;
                setcookie('cart', json_encode($cartData), time() + (86400 * 30), '/');

                // Send a success response back to the client
                echo json_encode(array('success' => true));
                exit();
            }
       } 
        else {
            // Handle invalid request
            echo json_encode(array('error' => 'Invalid request'));
            exit();
        }
        
    }
        
?>
